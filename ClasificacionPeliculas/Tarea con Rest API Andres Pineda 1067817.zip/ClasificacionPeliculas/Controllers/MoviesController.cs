﻿using Microsoft.AspNetCore.Mvc;
using ClasificacionPeliculasModel;

namespace ClasificacionPeliculas.Controllers
{
  public class MoviesController : Controller
  {
    private readonly IMoviesService ms;

    public MoviesController(IMoviesService ms)
    {
      this.ms = ms;
    }

    // GET: Movies
    public async Task<IActionResult> Index()
    {
      return View(await ms.GetMovies());
    }

    // GET: Movies/Details/5
    public async Task<IActionResult> Details(int id)
    {
      var movie = await getMoviesWithVotes(id);
      if (movie == null) return NotFound();
      return View(movie);
    }

    // GET: Movies/Create
    public IActionResult Create()
    {
      return View();
    }

    // POST: Movies/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("Id,Title,ReleaseDate,Duration,Director,Actors,Plot,Rating,Votes,PosterUrl,ImdbId")] Movie movie)
    {
      if (ModelState.IsValid)
      {
        await ms.CreateMovie(movie);
        return RedirectToAction(nameof(Index));
      }
      return View(movie);
    }

    // GET: Movies/Edit/5
    public async Task<IActionResult> Edit(int? id)
    {
      var movie = await getMoviesWithVotes((int)id);
      if (movie == null) return NotFound();
      return View(movie);
    }

    // POST: Movies/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("Id,Title,ReleaseDate,Duration,Director,Actors,Plot,Rating,Votes,PosterUrl,ImdbId")] ClasificacionPeliculasModel.Movie movie)
    {
      if (!ModelState.IsValid) return View(movie);
      await ms.UpdateMovie(movie);
      return RedirectToAction(nameof(Index));
    }


    // GET: Movies/Delete/5
    public async Task<IActionResult> Delete(int id)
    {
      var movie = await getMoviesWithVotes(id);
      if (movie == null) return NotFound();
      return View(movie);
    }

    // POST: Movies/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
      await ms.DeleteMovie(id);
      return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    public async Task<JsonResult> GetMovieJson()
    {
      int movieId = Convert.ToInt32(HttpContext.Request.Form["movieId"].FirstOrDefault().ToString());
      return Json(new { movie = await getMoviesWithVotes((int)movieId) });
      //   MoviesContext _moviesContext = new MoviesContext();

      //   ClasificacionPeliculasModel.Movie movie = (from m in _moviesContext.Movies
      //                                              where m.Id == movieId
      //                                              select new ClasificacionPeliculasModel.Movie
      //                                              {
      //                                                Title = m.Title,
      //                                                ReleaseDate = m.ReleaseDate,
      //                                                Duration = m.Duration,
      //                                                Director = m.Director,
      //                                                Actors = m.Actors

      //                                              }).FirstOrDefault();
      //   var jsonresult = new { movie = movie };

      //   return Json(jsonresult);
    }




    // Helpers 
    private async Task<Movie> getMoviesWithVotes(int id)
    {
      return await ms.GetMovie((int)id);
      // Movie movie = (
      //     from m in _context.Movies
      //     where m.Id == id
      //     select new Movie {
      //         Id = m.Id,
      //         Title = m.Title,
      //         ReleaseDate = m.ReleaseDate,
      //         Duration = m.Duration,
      //         Director = m.Director,
      //         Actors = m.Actors,
      //         Plot = m.Plot,
      //         Rating = m.Rating,
      //         Votes = m.Votes,
      //         PosterUrl = m.PosterUrl,
      //         ImdbId = m.ImdbId
      //     } 
      // ).First();
      // movie.VotesNavigation = _context.Votes.Where(vt => vt.MoviesId == movie.Id).Select(x => x).ToList();
      // movie.Votes = movie.VotesNavigation.Count();
      // movie.Rating = (movie.Votes > 0) ? (decimal)movie.VotesNavigation.Select(x => x.Rate).Average() : 0;
      // return movie;
    }
  }
}
