CREATE TABLE Movies (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  release_date DATE NOT NULL,
  duration INTEGER NOT NULL,
  director VARCHAR(255) NOT NULL,
  actors TEXT NOT NULL,
  plot TEXT NOT NULL,
  rating DECIMAL(3,1) NOT NULL,
  votes INTEGER NOT NULL,
  poster_url VARCHAR(255) NOT NULL,
  imdb_id VARCHAR(10) NOT NULL UNIQUE
);

CREATE TABLE Categories (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL
);

CREATE TABLE MoviesCategories (
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  movie_id INTEGER NOT NULL,
  category_id INTEGER NOT NULL,
  FOREIGN KEY (movie_id) REFERENCES Movies(id),
  FOREIGN KEY (category_id) REFERENCES Categories(id)
);

INSERT INTO Movies (title, release_date, duration, director, actors, plot, rating, votes, poster_url, imdb_id)
VALUES ('The Matrix', '1999-03-31', 136, 'The Wachowski Brothers', 'Keanu Reeves, Laurence Fishburne, Carrie-Anne Moss', 'A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.', 8.7, 1641192, 'https://www.imdb.com/title/tt0133093/mediaviewer/rm2062304000/', 'tt0133093');

INSERT INTO Movies (title, release_date, duration, director, actors, plot, rating, votes, poster_url, imdb_id)
VALUES ('Forrest Gump', '1994-07-06', 142, 'Robert Zemeckis', 'Tom Hanks, Robin Wright, Gary Sinise, Sally Field', 'The presidencies of Kennedy and Johnson, the events of Vietnam, Watergate and other historical events unfold through the perspective of an Alabama man with an IQ of 75, whose only desire is to be reunited with his childhood sweetheart.', 8.8, 1888015, 'https://www.imdb.com/title/tt0109830/mediaviewer/rm695361536/', 'tt0109830');

INSERT INTO Movies (title, release_date, duration, director, actors, plot, rating, votes, poster_url, imdb_id)
VALUES ('The Social Network', '2010-10-01', 120, 'David Fincher', 'Jesse Eisenberg, Andrew Garfield, Justin Timberlake, Armie Hammer', 'As Harvard student Mark Zuckerberg creates the social networking site that would become known as Facebook, he is sued by the twins who claimed he stole their idea, and by the co-founder who was later squeezed out of the business.', 7.7, 650386, 'https://www.imdb.com/title/tt1285016/mediaviewer/rm3851806208/', 'tt1285016');


INSERT INTO Categories (name)
VALUES ('Action');

INSERT INTO Categories (name)
VALUES ('Comedy');

INSERT INTO Categories (name)
VALUES ('Drama');

INSERT INTO MoviesCategories (movie_id, category_id)
VALUES (1, 1);

INSERT INTO MoviesCategories (movie_id, category_id)
VALUES (2, 3);

INSERT INTO MoviesCategories (movie_id, category_id)
VALUES (3, 3);

INSERT INTO MoviesCategories (movie_id, category_id)
VALUES (3, 2);
